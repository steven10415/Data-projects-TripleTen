
# Sprint 5 Project

This project is to prepare for an analysis for Superstore on what is causing customers to return their orders and how to reduce the volume of returned orders. 


## Tableau Public Link
https://public.tableau.com/shared/Y62H7Y7WJ?:display_count=n&:origin=viz_share_link

